#include "Interpolation.h"


double Interpolation::g(int currentIndex) {
	double dividend(1), divider(1);
	int i(0);
	int ptr = currentIndex;
	while (i < storageOfData.size()) {
		for (i; i < ptr; i++) {
			dividend *= value - storageOfData[i].first;
			divider *= storageOfData[currentIndex].first - storageOfData[i].first;
		}
		if (dividend == 0)
			return 0;
		ptr = storageOfData.size();
		i++;
	}
	return dividend / divider;
}

void Interpolation::P() {
	double sum(0);
	for (int i(0); i < storageOfData.size(); i++) {
		sum += storageOfData[i].second * g(i);
	}
	answer = sum;
	std::cout << sum;
	auto it = storageOfData.begin();
	for (int i(0); i < storageOfData.size();) {
		if (value > storageOfData[i].first)
			i++;
		else {
			storageOfData.insert(it + i, std::make_pair(value, sum));
			break;
		}
	}
}