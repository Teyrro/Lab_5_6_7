#pragma once
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <iostream>


using ValueAndAnswer = std::pair<double, double>;

class Interpolation {
private:
	double g(int currentIndex);

protected:
	std::vector<ValueAndAnswer> storageOfData;
	double value;
	double answer;
public:
	Interpolation(std::string fileName) {
		std::ifstream input(fileName);
		unsigned short size;
		input >> size;
		storageOfData.resize(size);
		for (int i(0); i < size; i++) {
			input >> storageOfData[i].first;
		}
		for (int i(0); i < size; i++) {
			input >> storageOfData[i].second;
		}

	}
	Interpolation(std::string fileName, double val) {
		std::ifstream input(fileName);
		unsigned short size;
		input >> size;
		storageOfData.resize(size);
		for (int i(0); i < size; i++) {
			input >> storageOfData[i].first;
		}
		for (int i(0); i < size; i++) {
			input >> storageOfData[i].second;
		}
		value = val;
	}
	void OutputData() {
		std::ofstream myfile;
		myfile.open("example.csv");
		for (auto& ptr : storageOfData) {
			myfile << ptr.first;
			myfile << "; ";
		}
		myfile << "\n";
		for (auto& ptr : storageOfData) {
			myfile << ptr.second;
			myfile << "; ";
		}
		myfile.close();
	}

	void P();


};

class Aitken_Interpolation : public Interpolation {
public:
	Aitken_Interpolation(std::string fileName, double val) : Interpolation(fileName, val) {}
	void FindAnswer() {

		short counter(storageOfData.size());
		std::vector<double> answer(storageOfData.size());
		for (int i(0); i < storageOfData.size(); i++) {
			answer[i] = storageOfData[i].second;
		}
		
		while (1 < counter--) {
			std::cout << "������� �������� " << counter << ", ";
			int l(0), r(storageOfData.size() - counter);
			std::cout << "l - " << l << " r - " << r << " ";
			for (l; l < counter; l++, r++) {
				answer[l] = (answer[l] * (value - storageOfData[r].first) - answer[l+1] * (value - storageOfData[l].first));
				answer[l] /= (storageOfData[l].first - storageOfData[r].first);
				std::cout << "P" << l << r << " " << answer[l] << " ";
			}
			std::cout << "\n";
		}
		std::cout << answer[0];
		auto it = storageOfData.begin();
		for (int i(0); i < storageOfData.size();) {
			if (value > storageOfData[i].first)
				i++;
			else {
				storageOfData.insert(it + i, std::make_pair(value, answer[0]));
				break;
			}
		}
	}

};
