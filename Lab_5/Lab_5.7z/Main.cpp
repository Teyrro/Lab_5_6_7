#include "Interpolation.h"
#include <Windows.h>

int main() {
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	//Interpolation f("StorageOfData.txt", 2);
	//f.FindAnswer();
	Aitken_Interpolation f("StorageOfData.txt" , 2.56);
	f.FindAnswer();
	f.OutputData();
}